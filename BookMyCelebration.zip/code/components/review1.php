<?php
// Database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sgp";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form was submitted using POST method
if (isset($_POST["Submit"])) {

    if (isset($_POST['name'], $_POST['email'], $_POST['review'], $_FILES['image'])) {
        // Get form data
        $name = $_POST['name'];
        $email = $_POST['email'];
        $review = $_POST['review'];

        // Handle the uploaded image
        $image = $_FILES['image'];

        // Check if image file is a real image or fake image
        $check = getimagesize($image["tmp_name"]);
        if($check === false) {
            echo "File is not an image.";
            exit();
        }

        // Check file size (limit to 2MB)
        if ($image["size"] > 2000000) {
            echo "Sorry, your file is too large.";
            exit();
        }

        // Allow certain file formats
        $imageFileType = strtolower(pathinfo($image["name"], PATHINFO_EXTENSION));
        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg") {
            echo "Sorry, only JPG, JPEG, & PNG files are allowed.";
            exit();
        }

        // Read the file as binary data (BLOB)
        $imageData = file_get_contents($image["tmp_name"]);

        // Prepare and bind the SQL statement to prevent SQL injection
        $stmt = $conn->prepare("INSERT INTO review1 (name, email, review, img) VALUES (?, ?, ?, ?)");
        if ($stmt === false) {
            die("Error preparing the SQL statement: " . $conn->error);
        }

        // Bind the parameters, note that 'b' is used for binary data (blob)
        $stmt->bind_param("sssb", $name, $email, $review, $null);  // sssb (three strings, one blob)
        $stmt->send_long_data(3, $imageData);  // Send binary image data

        // Execute the statement
        if ($stmt->execute()) {
            // Redirect to home page after successful submission
            echo '<script type="text/javascript">
                window.location.href = "/Project/code/components/index.html";
            </script>';
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    } else {
        echo "Form data is incomplete.";
    }
}

// Close the database connection
$conn->close();
?>
