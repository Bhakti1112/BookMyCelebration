<?php
// Database connection
$servername = "localhost";
$username = "root"; // Your database username
$password = ""; // Your database password
$dbname = "sgp"; // Your database name

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email']; // Email entered by the user
    $new_password = $_POST['new_password']; // New password
    $confirm_password = $_POST['confirm_password']; // Confirmation of the new password

    // Ensure passwords match
    if ($new_password !== $confirm_password) {
        echo "<script>alert('Passwords do not match. Please try again.');</script>";
        exit;
    }

    // Hash the new password
    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    // Update the password for the provided email
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
    if (!$stmt) {
        echo "<script>alert('Error preparing the statement.');</script>";
        exit;
    }
    $stmt->bind_param("ss", $hashed_password, $email);

    if ($stmt->execute()) {
        if ($stmt->affected_rows > 0) {
            echo "<script>alert('Password reset successfully.');</script>";
        } else {
            echo "<script>alert('No account found with this email.');</script>";
        }
    } else {
        echo "<script>alert('Error updating password.');</script>";
    }

    $stmt->close();
}

$conn->close();
?>
