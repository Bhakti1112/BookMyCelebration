<?php
include 'db.php'; // Assumes db.php contains the connection $conn

function getEvents($conn) {
    echo "hello";
    $sql = "SELECT * FROM event1";
    
    // Check if query is successful
    if ($result = $conn->query($sql)) {
        if ($result->num_rows > 0) {
            $events = array();
            while ($row = $result->fetch_assoc()) {
                $events[] = $row;
            }
            return $events;
           
        } else {
            // If no rows found
            return [];
        }
    } else {
        // If query fails, handle the error
        die("Query failed: " . $conn->error);
    }
}
?>
