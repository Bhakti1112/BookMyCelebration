
<!-- 
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Your CSS and JavaScript files here 
</head> -->

<!DOCTYPE html>
<html lang="en">
  <head>
    
    <link rel="stylesheet" href="cta.css">
    <title>Home</title>
    <link rel="icon" href="https://i.postimg.cc/Bnq1ShFs/logo.jpg" height:100; width:100; type="image/png">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="utf-8" />
    <meta property="twitter:card" content="summary_large_image" />

    <style data-tag="reset-style-sheet">
      html {  line-height: 1.15;}body {  margin: 0;}* {  box-sizing: border-box;  border-width: 0;  border-style: solid;}p,li,ul,pre,div,h1,h2,h3,h4,h5,h6,figure,blockquote,figcaption {  margin: 0;  padding: 0;}button {  background-color: transparent;}button,input,optgroup,select,textarea {  font-family: inherit;  font-size: 100%;  line-height: 1.15;  margin: 0;}button,select {  text-transform: none;}button,[type="button"],[type="reset"],[type="submit"] {  -webkit-appearance: button;}button::-moz-focus-inner,[type="button"]::-moz-focus-inner,[type="reset"]::-moz-focus-inner,[type="submit"]::-moz-focus-inner {  border-style: none;  padding: 0;}button:-moz-focus,[type="button"]:-moz-focus,[type="reset"]:-moz-focus,[type="submit"]:-moz-focus {  outline: 1px dotted ButtonText;}a {  color: inherit;  text-decoration: inherit;}input {  padding: 2px 4px;}img {  display: block;}html { scroll-behavior: smooth  }
    </style>
    <style data-tag="default-style-sheet">
        .styled-table {
    border: 2px solid black;
    border-collapse: collapse;
    width: 100%;
}
.styled-table th, .styled-table td {
    border: 2px solid black;
    padding: 8px;
    text-align: left;
}
      html {
        font-family: Inter;
        font-size: 16px;
      }
      body {
        font-weight: 400;
        font-style:normal;
        text-decoration: none;
        text-transform: none;
        letter-spacing: normal;
        line-height: 1.15;
        color: var(--dl-color-theme-neutral-dark);
        background-color: var(--dl-color-theme-neutral-light);

        fill: var(--dl-color-theme-neutral-dark);
      }
    </style>
    <link
      rel="stylesheet"
      href="https://unpkg.com/animate.css@4.1.1/animate.css"
    />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
      data-tag="font"
    />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=STIX+Two+Text:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&amp;display=swap"
      data-tag="font"
    />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
      data-tag="font"
    />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
      data-tag="font"
    />
    <link
      rel="stylesheet"
      href="https://unpkg.com/@teleporthq/teleport-custom-scripts/dist/style.css"
    />
    <style>
      @keyframes fade-in-left {
        0% {
          opacity: 0;
          transform: translateX(-20px);
        }
        100% {
          opacity: 1;
          transform: translateX(0);
        }
      }
    </style>
  </head>
  <body>
    <link rel="footer.css" href="../footer.css"/>
    <link rel="stylesheet" href="style.css" />
    <div>
      <link href="./index.css" rel="stylesheet" />

      <div class="home-container">
        <navbar-wrapper>
          <header class="navbar-container">
            <header data-thq="thq-navbar" class="navbar-navbar-interactive">
              <img
                alt="Event Agency Logo"
                src="https://i.postimg.cc/Bnq1ShFs/logo.jpg"
                class="navbar-image1"
              />
              <div data-thq="thq-navbar-nav" class="navbar-desktop-menu">
                <nav class="navbar-links">
                  <span class="thq-link thq-body-small"><span> <a href="Adminindex.html">Home</a></span>
                 </span>
                 <span class="thq-link thq-body-small">
                  <span> <a href="Adminpricing.html">Packages</a></span>
                </span>
                  <!-- <span class="thq-link thq-body-small">
                    <span> <a href="gallery.html">Gallery</a></span>
                  </span> -->
                 
                  <span class="thq-link thq-body-small">
                    <span> <a href="Admintestimonial.html">Review</a></span>
                  </span>
                  <span class="thq-link thq-body-small">
                    <span> <a href="Admin.html">Booked Events</a></span>
                  </span>
                </nav>
                <div class="navbar-buttons">
                  <!-- <button
                    class="navbar-action1 thq-button-animated thq-button-filled"
                  >
                    <span class="thq-body-small"><a href="loginandsignup.html">Log in</a></span>
                  </button> -->
                  <button
                  class="navbar-action1 thq-button-animated thq-button-filled"
                >
                  <span class="thq-body-small"><a href="logout.php">Log out</a></span>
                </button>
                  
                </div>
              </div>
              <div data-thq="thq-burger-menu" class="navbar-burger-menu">
                <svg viewBox="0 0 1024 1024" class="navbar-icon">
                  <path
                    d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"
                  ></path>
                </svg>
              </div>

            </header>
          </header>
        </navbar-wrapper>

    <div class="home-container">
    <?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
$server = "localhost";
$username = "root"; // Replace with your DB username
$password = "";     // Replace with your DB password
$database = "sgp"; // Replace with your DB name

// Create the MySQLi connection
$mysqli = new mysqli($server, $username, $password, $database);

// Check if the connection was successful
if ($mysqli->connect_error) {
    die("Database connection failed: " . $mysqli->connect_error);
}

// SQL query to fetch data
$sql = "SELECT * FROM event1"; // Replace with your table name

// Execute the query
$result = $mysqli->query($sql);

// Check if the query was successful
if (!$result) {
    die("SQL Error: " . $mysqli->error);
}
?>
    <?php
    // Check if there are records in the result
    if ($result->num_rows > 0) {
        echo "<table class='styled-table'>";

        echo "<tr><th>ID</th><th>Name</th><th>Contact</th><th>event type</th><th>Date</th><th>Time</th><th>Package</th></tr>"; // Change columns as per your table structure

        // Loop through each row and display the data
       
        // Loop through each row and display the data
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . (isset($row['e_id']) ? $row['e_id'] : 'N/A') . "</td>"; // Replace 'event_id' with actual column name
            echo "<td>" . (isset($row['cust_name']) ? $row['cust_name'] : 'N/A') . "</td>"; // Replace 'name' with actual column name
            echo "<td>" . (isset($row['contect']) ? $row['contect'] : 'N/A') . "</td>";
            echo "<td>" . (isset($row['event_type']) ? $row['event_type'] : 'N/A') . "</td>";
            echo "<td>" . (isset($row['date']) ? $row['date'] : 'N/A') . "</td>";
            echo "<td>" . (isset($row['time']) ? $row['time'] : 'N/A') . "</td>";
            echo "<td>" . (isset($row['package']) ? $row['package'] : 'N/A') . "</td>"; // Replace 'email' with actual column name
            echo "</tr>";
        }
      
        

        echo "</table>";
    } else {
        echo "<p>No records found.</p>";
    }

    // Close the database connection
    $mysqli->close();
    ?>
    </div>
    </div>
</div>

<link rel="stylesheet" href="../style.css" />

      </div>
    </div>
  </footer>

</body>
</html>
<style>
.events-table {
    border-collapse: collapse;
    width: 100%;
}

.events-table th, .events-table td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

.events-table th {
    background-color: #f0f0f0;
}
</style>



