<?php
// Include database connection
include 'db.php';
include 'session_check.php';
 
// Initialize a variable to track booking success
$booking_success = false;
//var_dump();
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $user_id = $_SESSION['user_id'];
    $firstname = $_POST['firstname'];
    $contactnumber = $_POST['contactnumber'];
    $eventname = $_POST['eventname'];
    $venue = $_POST['venue'];
    $eventdate = $_POST['eventdate'];
    $eventtime = $_POST['eventtime'];
    $package_type = $_POST['package_type'];

    // Validate input data
    if (empty($firstname) || empty($contactnumber) || empty($eventname) || 
        empty($venue) || empty($eventdate) || empty($eventtime) || empty($package_type)) {
        die("Please fill all required fields.");
    }

    // Prepare the SQL query with placeholders
    $sql = "INSERT INTO events (user_id, name, contact_number, event_type, venue, event_date, event_time, package_type) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare the statement
    if ($stmt = $conn->prepare($sql)) {
        // Bind the variables to the prepared statement as parameters
        $stmt->bind_param("isssssss", $user_id, $firstname, $contactnumber, $eventname, $venue, $eventdate, $eventtime, $package_type);

        // Execute the query and check for success
        if ($stmt->execute()) {
            header('Location: index.html');
            $booking_success = true; // Set booking success to true
            // Redirect to payment or show a success message
             
        } else {
            // Display an error message if the execution fails
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    } else {
        // Display an error message if the statement preparation fails
        echo "Error preparing statement: " . $conn->error;
    }

    // Close the database connection
    $conn->close();
}
?>
