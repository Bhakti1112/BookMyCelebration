<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    // If the user is not logged in, store the target page and redirect to login page
    $_SESSION['redirect_to'] = 'index.html';
    header('Location: loginandsignup.html');
    exit();
} else {
    // If the user is logged in, redirect to the celebration form page
    header('Location: booknow.html');
    exit();
}
