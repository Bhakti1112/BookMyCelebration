<?php
// Database connection
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'sgp';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Fetch testimonials from the database
$sql = "SELECT name, review, img FROM review1";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Review</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="utf-8" />
    <meta property="twitter:card" content="summary_large_image" />

    <style data-tag="reset-style-sheet">
      html {  line-height: 1.15;}body {  margin: 0;}* {  box-sizing: border-box;  border-width: 0;  border-style: solid;}p,li,ul,pre,div,h1,h2,h3,h4,h5,h6,figure,blockquote,figcaption {  margin: 0;  padding: 0;}button {  background-color: transparent;}button,input,optgroup,select,textarea {  font-family: inherit;  font-size: 100%;  line-height: 1.15;  margin: 0;}button,select {  text-transform: none;}button,[type="button"],[type="reset"],[type="submit"] {  -webkit-appearance: button;}button::-moz-focus-inner,[type="button"]::-moz-focus-inner,[type="reset"]::-moz-focus-inner,[type="submit"]::-moz-focus-inner {  border-style: none;  padding: 0;}button:-moz-focus,[type="button"]:-moz-focus,[type="reset"]:-moz-focus,[type="submit"]:-moz-focus {  outline: 1px dotted ButtonText;}a {  color: inherit;  text-decoration: inherit;}input {  padding: 2px 4px;}img {  display: block;}html { scroll-behavior: smooth  }
    </style>
    <style data-tag="default-style-sheet">
      html {
        font-family: Inter;
        font-size: 16px;
      }

      body {
        font-weight: 400;
        font-style:normal;
        text-decoration: none;
        text-transform: none;
        letter-spacing: normal;
        line-height: 1.15;
        color: var(--dl-color-theme-neutral-dark);
        background-color: var(--dl-color-theme-neutral-light);

        fill: var(--dl-color-theme-neutral-dark);
      }
    </style>
    <link
      rel="stylesheet"
      href="https://unpkg.com/animate.css@4.1.1/animate.css"
    />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
      data-tag="font"
    />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=STIX+Two+Text:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&amp;display=swap"
      data-tag="font"
    />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Noto+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
      data-tag="font"
    />
    <link
      rel="stylesheet"
      href="https://fonts.googleapis.com/css2?family=Inter:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap"
      data-tag="font"
    />
    <link
      rel="stylesheet"
      href="https://unpkg.com/@teleporthq/teleport-custom-scripts/dist/style.css"
    />
    <style>
      @keyframes fade-in-left {
        0% {
          opacity: 0;
          transform: translateX(-20px);
        }
        100% {
          opacity: 1;
          transform: translateX(0);
        }
      }
    </style>
  </head>
  <body>
    <link rel="stylesheet" href="../style.css" />
    <div>
      <link href="navbar.css" rel="stylesheet" />
      <header class="navbar-container">
        <header data-thq="thq-navbar" class="navbar-navbar-interactive">
          <img
            alt="Event Agency Logo"
            src="https://i.postimg.cc/Bnq1ShFs/logo.jpg"crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w5MTMyMXwwfDF8c2VhcmNofDMzfHxiYWxsb258ZW58MHx8fHwxNzIyNjc5ODUzfDA&amp;ixlib=rb-4.0.3&amp;q=80&amp;w=1080"
            class="navbar-image1"
          />
          <div data-thq="thq-navbar-nav" class="navbar-desktop-menu">
            <nav class="navbar-links">
              <span class="thq-link thq-body-small"><span> <a href="Adminindex.html">Home</a></span>
                 </span>
                 <span class="thq-link thq-body-small">
                  <span> <a href="Adminpricing.html">Packages</a></span>
                </span>
                  <!-- <span class="thq-link thq-body-small">
                    <span> <a href="gallery.html">Gallery</a></span>
                  </span> -->
                  <span class="thq-link thq-body-small">
                    <span> <a href="Admintestimonial.html">Review</a></span>
                  </span>
                  <span class="thq-link thq-body-small">
                    <span> <a href="Admin.php">Booked Events</a></span>
                  </span>
            </nav>
           
          </div>
          <div data-thq="thq-burger-menu" class="navbar-burger-menu">
            <svg viewBox="0 0 1024 1024" class="navbar-icon">
              <path
                d="M128 554.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 298.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667zM128 810.667h768c23.552 0 42.667-19.115 42.667-42.667s-19.115-42.667-42.667-42.667h-768c-23.552 0-42.667 19.115-42.667 42.667s19.115 42.667 42.667 42.667z"
              ></path>
            </svg>
          </div>
          <div data-thq="thq-mobile-menu" class="navbar-mobile-menu">
            <div class="navbar-nav">
              <div class="navbar-top">
                <img
                  alt="Event Agency Logo"
                  src="https://images.unsplash.com/photo-1708368429776-21c4fde7a6f0?crop=entropy&amp;cs=tinysrgb&amp;fit=max&amp;fm=jpg&amp;ixid=M3w5MTMyMXwwfDF8c2VhcmNofDMzfHxiYWxsb258ZW58MHx8fHwxNzIyNjc5ODUzfDA&amp;ixlib=rb-4.0.3&amp;q=80&amp;w=1080"
                  class="navbar-logo"
                />
                <div data-thq="thq-close-menu" class="navbar-close-menu">
                  <svg viewBox="0 0 1024 1024" class="navbar-icon2">
                    <path
                      d="M810 274l-238 238 238 238-60 60-238-238-238 238-60-60 238-238-238-238 60-60 238 238 238-238z"
                    ></path>
                  </svg>
                </div>
              </div>
              <div data-thq="thq-navbar-nav" class="navbar-desktop-menu">
                <nav class="navbar-links">
                  <span class="thq-link thq-body-small"><span> <a href="Adminindex.html">Home</a></span>
                     </span>
                     <span class="thq-link thq-body-small">
                      <span> <a href="Adminpricing.html">Packages</a></span>
                    </span>
                      <!-- <span class="thq-link thq-body-small">
                        <span> <a href="gallery.html">Gallery</a></span>
                      </span> -->
                      <span class="thq-link thq-body-small">
                        <span> <a href="Admincontact.html">Contact</a></span>
                      </span>
                      <span class="thq-link thq-body-small">
                        <span> <a href="Admintestimonial.html">Review</a></span>
                      </span>
                      <span class="thq-link thq-body-small">
                        <span> <a href="Admin.html">Booked Events</a></span>
                      </span>
                </nav>
                <div class="navbar-buttons">
                  <button
                        class="navbar-action1 thq-button-animated thq-button-filled"
                      >
                      <span class="thq-body-small"><a href="login.html">Log out</a></span>
                      </button>
                 
                </div>
         
          </div>
        </header>
      </header>
    </div>
    <script
      data-section-id="navbar"
      src="https://unpkg.com/@teleporthq/teleport-custom-scripts"
    ></script>
    <link rel="stylesheet" href="../style.css" />
    <div>
      <link href="testimonial.css" rel="stylesheet" />
    <div class="thq-section-padding">
        <div class="testimonial-max-width thq-section-max-width">
            <div class="testimonial-container">
                <h2 class="thq-heading-2"><span>Testimonials</span></h2>
                <span class="testimonial-text01 thq-body-small">
                    <span>
                        See what our customers have to say about their experience with us.
                    </span>
                </span>
            </div>
            <div class="thq-grid-2">
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        // Convert the BLOB image data to Base64
                        $imageData = base64_encode($row['img']);
                        $imageSrc = 'data:image/jpeg;base64,' . $imageData;

                        echo '<div class="thq-animated-card-bg-2">';
                        echo '  <div class="thq-animated-card-bg-1">';
                        echo '      <div data-animated="true" class="thq-card testimonial-card">';
                        echo '          <div class="testimonial-container02">';
                        echo '              <img alt="Image of ' . htmlspecialchars($row['name']) . '" src="' . $imageSrc . '" class="testimonial-image" />';
                        echo '              <div class="testimonial-container03">';
                        echo '                  <strong class="thq-body-large">';
                        echo '                      <span>' . htmlspecialchars($row['name']) . '</span>';
                        echo '                  </strong>';
                        echo '                  <span class="thq-body-small">';
                        echo '                      <span>' . htmlspecialchars($row['review']) . '</span>';
                        echo '                  </span>';
                        echo '              </div>';
                        echo '          </div>';
                        echo '      </div>';
                        echo '  </div>';
                        echo '</div>';
                    }
                } else {
                    echo '<p>No testimonials available.</p>';
                }
                ?>
            </div>
        </div>
    </div>
</body>
</html>

<?php
$conn->close();
?>
