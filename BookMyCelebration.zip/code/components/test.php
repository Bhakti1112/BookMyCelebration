<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sgp";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetching the images from the review1 table
$sql = "SELECT img FROM review1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Display each image using the path stored in the 'img' column
        $imagePath = $row['img'];
        // Ensure the image path is correct
        echo '<img src="' . $imagePath . '" alt="Review Image" style="width:150px;height:150px;">';
    }
} else {
    echo "No images found.";
}

$conn->close();
?>
