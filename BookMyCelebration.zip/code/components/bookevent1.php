<?php

// Include database connection
include 'db.php';

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect input data from form
    $cust_name = $_POST["firstname"];  
    $contact = $_POST["contactnumber"];  // Corrected variable name
    $eventtype = $_POST["eventname"];
    $eventdate = $_POST["eventdate"];
    $eventtime = $_POST["eventtime"];
    $package = $_POST["package_type"];

    // Validate input data
    if (empty($cust_name) || empty($contact) || empty($eventtype) || empty($eventdate) || empty($eventtime) || empty($package)) {
        echo "Please fill out all fields.";
    } else {
        // Prepare the SQL query
        $sql = "INSERT INTO event1 (cust_name, contect, event_type, date, time, package) 
                VALUES (?, ?, ?, ?, ?, ?)";

        // Prepare the statement
        if ($stmt = $conn->prepare($sql)) {
            // Bind the variables to the prepared statement as parameters
            $stmt->bind_param("ssssss", $cust_name, $contact, $eventtype, $eventdate, $eventtime, $package);

            // Execute the query
            if ($stmt->execute()) {
                echo "Event booked successfully!";
            } else {
                echo "Error booking event: " . $stmt->error;
            }

            // Close the statement and connection
            $stmt->close();
            $conn->close();
        } else {
            echo "Error preparing statement: " . $conn->error;
        }
    }
}

?>
