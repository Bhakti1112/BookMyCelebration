<?php
include 'db.php'; // Make sure db.php contains the connection $conn

$sql = "SELECT * FROM event1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data for each row
    while ($row = $result->fetch_assoc()) {
        echo "Event ID: " . $row["e_id"] . " - Name: " . $row["cust_name"] . " - Contact: " . $row["contect"] . " - Event Type: " . $row["event_type"] . " - Date: " . $row["date"] . " - Time: " . $row["time"] . " - Package: " . $row["package"] . "<br>";
    }
} else {
    echo "No events found";
}
?>
