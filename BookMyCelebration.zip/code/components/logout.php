<?php
// Start the session
session_start();

// Destroy all session data
session_unset();
session_destroy();

// Redirect to the login page or homepage
echo '<script type="text/javascript">
                window.location.href = "/Project/code/components/login.html";
            </script>';
exit();
?>
