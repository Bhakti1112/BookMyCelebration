document.querySelectorAll('input[name="payment_method"]').forEach((elem) => {
    elem.addEventListener('change', function(event) {
        const value = event.target.value;

        document.getElementById('creditCardDetails').style.display = value === 'Credit Card' ? 'block' : 'none';
        document.getElementById('debitCardDetails').style.display = value === 'Debit Card' ? 'block' : 'none';
        document.getElementById('paypalDetails').style.display = value === 'PayPal' ? 'block' : 'none';
    });
});

document.getElementById('paymentForm').addEventListener('submit', function(e) {
    e.preventDefault();

    const amount = document.getElementById('amount').value;
    const method = document.querySelector('input[name="payment_method"]:checked').value;

    // Simulate payment processing
    alert(`Payment of $${amount} using ${method} has been processed successfully!`);

    // Call function to generate PDF
    generatePDF(amount, method);
});

function generatePDF(amount, method) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    doc.text(20, 20, `Payment Confirmation`);
    doc.text(20, 30, `Amount: $${amount}`);
    doc.text(20, 40, `Payment Method: ${method}`);

    // Save PDF
    doc.save('payment-confirmation.pdf');
}
